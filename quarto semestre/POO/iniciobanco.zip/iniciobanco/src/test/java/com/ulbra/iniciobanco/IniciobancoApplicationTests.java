package com.ulbra.iniciobanco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IniciobancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
