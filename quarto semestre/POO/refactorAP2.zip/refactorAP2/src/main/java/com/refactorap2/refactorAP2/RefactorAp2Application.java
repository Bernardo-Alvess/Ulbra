package com.refactorap2.refactorAP2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefactorAp2Application {

	public static void main(String[] args) {
		SpringApplication.run(RefactorAp2Application.class, args);
	}

}
