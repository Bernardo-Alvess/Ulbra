public interface Andador {
    void andar();
}
