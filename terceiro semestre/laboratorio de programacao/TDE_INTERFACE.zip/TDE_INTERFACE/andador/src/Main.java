public class Main {
    public static void main(String[] args) {
        Atleta atleta = new Atleta();
        atleta.andar();
        atleta.correr();
    }
}