public interface Corredor {
    void correr();
}
