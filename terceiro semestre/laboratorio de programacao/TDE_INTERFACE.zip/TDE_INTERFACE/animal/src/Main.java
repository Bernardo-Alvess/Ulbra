public class Main {
    public static void main(String[] args) {
        Gato gato = new Gato();
        gato.comer();
        gato.dormir();

        Cachorro cachorro = new Cachorro();
        cachorro.comer();
        cachorro.dormir();

        Elefante elefante = new Elefante();
        elefante.comer();
        elefante.dormir();
    }
}