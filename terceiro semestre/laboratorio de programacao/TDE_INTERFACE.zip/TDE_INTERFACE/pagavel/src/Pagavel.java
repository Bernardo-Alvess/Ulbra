public interface Pagavel {
    void pagar();
    boolean verificarPagamento();
}
