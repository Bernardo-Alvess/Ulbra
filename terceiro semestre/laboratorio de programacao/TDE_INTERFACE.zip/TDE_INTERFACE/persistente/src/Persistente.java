interface Persistente {
    void salvar();
    void atualizar();
    void deletar();
    void buscar();
}
