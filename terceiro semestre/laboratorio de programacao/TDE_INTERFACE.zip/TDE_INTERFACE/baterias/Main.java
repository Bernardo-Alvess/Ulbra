public class Main {
    public static void main(String[] args) {
        Bateria bateria = new Bateria();
        bateria.carga();
        ((Descarregavel) bateria).carga();
    }
}