public interface Descarregavel {
    void carga();
}
