public interface Carregavel {
    void carga();
}
