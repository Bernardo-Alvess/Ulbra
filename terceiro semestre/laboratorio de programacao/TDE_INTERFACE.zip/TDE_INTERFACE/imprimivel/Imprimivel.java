public interface Imprimivel {

   void imprimir();

}
