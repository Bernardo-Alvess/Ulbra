public class Produto {
    String codigo;
    double preco;

    public Produto(String codigo, double preco){
        this.codigo = codigo;
        this.preco = preco;
    }
}
