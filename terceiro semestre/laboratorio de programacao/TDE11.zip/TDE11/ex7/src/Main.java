public class Main {
    public static void main(String[] args) {
        Produto produto = new Produto("12349150", 14.99);
        ProdutoPerecivel produtoPerecivel = new ProdutoPerecivel("1234335803485",20, "2023-07-10");
    }
}