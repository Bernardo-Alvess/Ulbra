public class Peixe extends Animal{
    @Override
    public void mover(){
        System.out.println("Nadando como um peixe");
    }
}
