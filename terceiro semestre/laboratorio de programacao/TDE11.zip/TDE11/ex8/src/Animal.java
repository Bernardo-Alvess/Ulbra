public class Animal {
    public void mover(){
        System.out.println("Animal movendo");
    }
}
