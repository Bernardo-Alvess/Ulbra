public class Main {
    public static void main(String[] args) {
        Animal animal = new Animal();
        Peixe peixe = new Peixe();

        animal.mover();
        peixe.mover();
    }
}