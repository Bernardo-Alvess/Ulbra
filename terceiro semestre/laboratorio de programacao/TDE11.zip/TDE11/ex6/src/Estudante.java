public class Estudante extends Pessoa{
    public void estudar(){
        System.out.println("Estudante estudando");
    }
}
