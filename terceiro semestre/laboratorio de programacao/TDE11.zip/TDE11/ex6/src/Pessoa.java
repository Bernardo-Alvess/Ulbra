public class Pessoa {
    public void falar(){
        System.out.println("Pessoa falando");
    }
    public void andar(){
        System.out.println("Pessoa andando");
    }
}
