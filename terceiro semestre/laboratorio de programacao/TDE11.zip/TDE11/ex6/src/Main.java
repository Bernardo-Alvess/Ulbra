public class Main {
    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa();
        Estudante estudante = new Estudante();

        pessoa.falar();
        pessoa.andar();
        estudante.estudar();
    }
}