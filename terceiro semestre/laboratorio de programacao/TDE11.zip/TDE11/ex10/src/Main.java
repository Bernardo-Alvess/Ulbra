public class Main {
    public static void main(String[] args) {
        Animal animal = new Animal();
        Gato gato = new Gato();

        animal.emitirSom();
        gato.emitirSom();
    }
}