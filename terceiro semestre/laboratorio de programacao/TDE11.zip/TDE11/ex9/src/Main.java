public class Main {
    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa("Bernardo", "Tão Tão Distante");
        Cliente cliente = new Cliente("Cliente", "Lugar nenhum", "123901820941");
    }
}