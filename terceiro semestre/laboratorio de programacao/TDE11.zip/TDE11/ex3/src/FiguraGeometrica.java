public class FiguraGeometrica {
    public void calcularArea(){
        //Calcular área de figura geométrica herdada
    }

    public void calcularPerimetro(){
        //calcular perimetro de figura geométrica herdada
    }
}
