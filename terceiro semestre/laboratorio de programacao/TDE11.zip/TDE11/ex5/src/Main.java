public class Main {
    public static void main(String[] args) {
        Animal animal = new Animal();
        Cachorro cachorro = new Cachorro();

        animal.emitirSom();
        cachorro.latir();
    }
}