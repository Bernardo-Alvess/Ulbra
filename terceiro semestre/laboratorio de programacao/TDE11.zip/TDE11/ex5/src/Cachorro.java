public class Cachorro extends Animal{
    public void latir(){
        System.out.println("au au");
    }
}
