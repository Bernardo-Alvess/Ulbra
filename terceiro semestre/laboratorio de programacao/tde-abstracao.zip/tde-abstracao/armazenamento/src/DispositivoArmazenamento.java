abstract class DispositivoArmazenamento {
    abstract void lerDados();
    abstract void gravarDados();
}