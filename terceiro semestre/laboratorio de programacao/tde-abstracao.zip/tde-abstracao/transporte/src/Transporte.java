abstract class Transporte {
    abstract void carregar();
    abstract void descarregar();
}