abstract class Funcionario {
    abstract double calcularSalario();
    abstract void realizarTarefa();
}
