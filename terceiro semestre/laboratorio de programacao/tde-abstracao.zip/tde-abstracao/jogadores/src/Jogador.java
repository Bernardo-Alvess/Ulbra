abstract class Jogador {
    abstract void atacar();
    abstract void defender();
}