public class Dinheiro extends Pagamento{
    public void realizarPagamento(){
        System.out.println("Pagamento no dinheiro");
    }

    public void emitirRecibo(){
        System.out.println("Recibo em dinheiro");
    }
}
