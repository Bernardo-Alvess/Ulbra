public abstract class Pagamento {
    public abstract void realizarPagamento();
    public abstract void emitirRecibo();
}
