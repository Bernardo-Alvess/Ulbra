abstract class Arquivo {
    abstract void abrir();
    abstract void fechar();
}