abstract class Produto {
    abstract double calcularPreco();
    abstract void exibirDetalhes();
}