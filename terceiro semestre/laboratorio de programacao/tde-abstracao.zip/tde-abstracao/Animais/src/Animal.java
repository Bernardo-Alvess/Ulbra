public abstract class Animal {
    abstract void comer();
    abstract void dormir();
    abstract void mover();
}