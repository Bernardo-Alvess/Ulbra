abstract class Impressora {
    abstract void imprimir();
    abstract void escanear();
}
