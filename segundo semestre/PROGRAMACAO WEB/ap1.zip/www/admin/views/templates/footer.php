    </section>
    </div>
    </div>

    <footer class="p-4 text-center">
        <h2>Meu rodapé</h2>
        <a href="../index.php">Área pública</a>
    </footer>
    
</body>
</html>