</section>
        </div>
    </div>

    <footer class="container-fluid bg-black p-4 text-white text-center">
        <h2>Meu rodapé</h2>
        <a href="admin/index.php">Área Administrativa</a>
    </footer>
    
</body>
</html>